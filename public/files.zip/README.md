# HamroLink Blog System
## MongoDB + Mongoose + Cloudinary + Next.js 14

---

## 📁 Files to copy into your project

| File | Deploy to |
|---|---|
| `types/blog.ts` | `types/blog.ts` |
| `models/BlogPost.ts` | `models/BlogPost.ts` |
| `lib/mongodb.ts` | `lib/mongodb.ts` |
| `lib/cloudinary.ts` | `lib/cloudinary.ts` |
| `lib/slugify.ts` | `lib/slugify.ts` |
| `app/api/upload/route.ts` | `app/api/upload/route.ts` |
| `app/api/blog/route.ts` | `app/api/blog/route.ts` |
| `app/api/blog/[slug]/route.ts` | `app/api/blog/[slug]/route.ts` |
| `app/api/admin/blog/route.ts` | `app/api/admin/blog/route.ts` |
| `app/api/admin/blog/[id]/route.ts` | `app/api/admin/blog/[id]/route.ts` |
| `components/admin/BlogEditor.tsx` | `components/admin/BlogEditor.tsx` |
| `components/blog/LikeCommentSection.tsx` | `components/blog/LikeCommentSection.tsx` |
| `app/admin/blog/page.tsx` | `app/admin/blog/page.tsx` |
| `app/admin/blog/new/page.tsx` | `app/admin/blog/new/page.tsx` |
| `app/admin/blog/[id]/page.tsx` | `app/admin/blog/[id]/page.tsx` |
| `app/[lang]/blog/[slug]/page.tsx` | `app/[lang]/blog/[slug]/page.tsx` |
| `.env.local.example` | `.env.local` (fill in values) |

---

## 📦 Install packages

```bash
npm install mongoose cloudinary
```

---

## ⚙️ Environment variables

Copy `.env.local.example` → `.env.local` and fill in:

```
MONGODB_URI=mongodb+srv://...
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...
```

---

## 🗺️ URL structure

### Public
| URL | Description |
|---|---|
| `/en/blog` | Blog index |
| `/ne/blog` | Blog index (Nepali) |
| `/en/blog/[slug]` | Article page |
| `/ne/blog/[slug]` | Article page (Nepali) |

### Admin
| URL | Description |
|---|---|
| `/admin/blog` | Post list + stats |
| `/admin/blog/new` | Create new post |
| `/admin/blog/[id]` | Edit post + moderate comments |

### API
| Endpoint | Method | Description |
|---|---|---|
| `/api/blog` | GET | List published posts |
| `/api/blog/[slug]` | GET | Single post (public) |
| `/api/blog/[slug]` | POST `{action:"like"}` | Toggle like |
| `/api/blog/[slug]` | POST `{action:"comment"}` | Submit comment |
| `/api/admin/blog` | GET | List all posts (admin) |
| `/api/admin/blog` | POST | Create post |
| `/api/admin/blog/[id]` | GET/PUT/DELETE | CRUD single post |
| `/api/admin/blog/[id]` | PATCH | Approve/delete comment |
| `/api/upload` | POST multipart | Upload image to Cloudinary |

---

## 📝 BlogPost Schema

| Field | Type | Notes |
|---|---|---|
| `slug` | String (unique) | Auto-generated from EN title |
| `title_en/ne` | String | Required |
| `excerpt_en/ne` | String | Shown on card |
| `body_en/ne` | String (HTML) | Full article HTML |
| `metaTitle_en/ne` | String | SEO title override |
| `metaDescription_en/ne` | String | SEO description |
| `category_en/ne` | String | |
| `categoryColor` | Enum | blue/violet/emerald/orange/pink/indigo/teal |
| `tags_en/ne` | String[] | |
| `featuredImage` | String | Cloudinary URL |
| `emoji` | String | Decorative emoji |
| `faqs` | FAQ[] | {question_en/ne, answer_en/ne} |
| `schema` | Object | JSON-LD overrides |
| `likes` | Number | Auto-incremented |
| `likedIps` | String[] | Deduplicate likes by IP |
| `comments` | Comment[] | {name, email, body, approved} |
| `published` | Boolean | Draft vs live |
| `readTime_en/ne` | String | Auto-estimated |

---

## 🔒 Security notes

- The admin routes (`/api/admin/*`, `/admin/*`) have **no auth** in this scaffold.
  Add your existing `middleware.ts` auth check or NextAuth session guard.
- Comments require admin approval before appearing publicly.
- Likes are deduplicated by IP address (server-side).
- Images are uploaded via Cloudinary with auto format/quality optimisation.

---

## ✅ Tailwind prose plugin (required for body rendering)

```bash
npm install @tailwindcss/typography
```

```js
// tailwind.config.js
plugins: [require("@tailwindcss/typography")]
```

This enables the `prose` classes used to style the article body HTML.
